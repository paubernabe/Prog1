/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinema;
import java.util.*;
/**
 *
 * @author paubc
 */
public class GestioCinema {
    
    
    public static void main (String [] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Quantes files té la sala");
        int files=sc.nextInt();
        System.out.println("Quantes columnes té la sala");
        int columnes=sc.nextInt();
        Cinema cinema= new Cinema(files+1,columnes+1);
        menuOpcions(cinema);
    }
    
    static void menuOpcions(Cinema cinema){
        int op,fila,columna;
        String [] menu=new String []{"MENU", "1.Ocupar Butaca", "2.Lliurar Butaca", "3.Lliurar totes butaques", "4.Mostrar Butaques", "5.Sortir"};
        
        
        Scanner sc=new Scanner(System.in);
        
        do{
        for (int i=0; i<menu.length; i++){
            System.out.println(menu[i]);
        }
        System.out.println("Escull una opció");
        op=sc.nextInt();
        switch(op){
            case 1:
                cinema.mostrarButaques();
                System.out.println("Digues la fila de la butaca a ocupar");
                fila=sc.nextInt();
                System.out.println("Digues la columna de la butaca a ocupar");
                columna=sc.nextInt();


                cinema.ocuparButaca(fila+1, columna+1);
                break;
            case 2:
                cinema.mostrarButaques();
                System.out.println("Digues la fila de la butaca a lliurar");
                fila=sc.nextInt();
                System.out.println("Digues la columna de la butaca a lliurar");
                columna=sc.nextInt();


                cinema.lliurarButaca(fila+1, columna+1);
                break;
            case 3:
                cinema.lliurarButaques();
                System.out.println("SALA LLIURADA!");
                break;
            case 4:
                cinema.mostrarButaques();
                break;
            case 5:
                System.exit(0);
                break;
                    
            
        }
            
        }while(op!=5);
    }
}
