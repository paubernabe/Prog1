/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nota;

/**
 *
 * @author paubc
 */
public class Alumne {
    static double maxPuntsExtra=1.5;
    String nom;
    double notaExamen1 ;
    double notaExamen2 ;
    double notaExamen3;
    double puntsExtra ;
    double notaFinal ;
    
    Alumne ( String nom , double nota1 , double nota2 , double nota3 , double puntsExtra ) {
        this . nom = nom ;
        this . notaExamen1 = nota1 ;
        this . notaExamen2 = nota2 ;
        this . notaExamen3 = nota3 ;
        this . puntsExtra = puntsExtra ;

    }
    
    static void modificarMaxPuntsExtra ( double max ){
        maxPuntsExtra = max ;
    }
    void calculaNotaFinal () {
        if (puntsExtra>maxPuntsExtra){
            this.notaFinal= (notaExamen1+notaExamen2+notaExamen3)/3+1.5;
 
        }
        else{
            this.notaFinal= ((notaExamen1+notaExamen2+notaExamen3)/3)+puntsExtra;
        }
    }
}

//PREGUNTES
/*
(b) En la classe Alumne, quins s´on atributs de classe i quins s´on atributs d’objecte? Raoneu
la vostra resposta.

R//
Els atributs d'objecte són tots, excepte el static double maxpuntsExtra. Això es deu a que
nosaltres al crear un objecte d'aquesta classe, podrem canviar els valors als atributs i a cada objecte tenir
valors diferents als nostres atributs.

En canvi el static maxpuntsextra, al ser un atribut de classe, serà el mateix valor per a tots els objectes.

*/
//-----------------------------------------------------------------------------------------
/*
Els m`etodes veureNotaFinalFormatText() i modificarMaxPuntsExtra() s´on m`etodes
de classe o m`etodes d’objecte? Per qu`e?

R// 
El metode veureNotaFinalFormatText() és un mètode d'objecte ja que només podem cridar-lo amb l'objecte 
d'aquella classe en particular. El podem cridar: objecteAlumne.metode()

En canvi modificarMaxPuntsExtra() és un mètode de classe ja que és static i a més no es pot cridar amb una
instancia de la classe.
El podem cridar: Alumne.metode()

*/