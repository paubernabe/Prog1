/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nota;

/**
 *
 * @author pau bernabe
 */
import java.util.*;
public class Nota {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Quin es el nom de l'alumne?");
        String nom=sc.next();
        System.out.println("Quina es la nota del primer examen?");
        double nota1=sc.nextDouble();
        System.out.println("Quina es la nota del segon examen?");
        double nota2=sc.nextDouble();
        System.out.println("Quina es la nota del tercer examen?");
        double nota3=sc.nextDouble();
        System.out.println("Quina es la nota extra de l'alumne?");
        double notaextra=sc.nextDouble();
                
        

        Alumne meualumne = new Alumne(nom,nota1,nota2,nota3,notaextra);
        meualumne.calculaNotaFinal();
        System.out.println("L'alumne " + meualumne.nom+ " té aquesta nota final: " +veureNotaFinalFormatText(meualumne.notaFinal));
        
        
        
        
    }
    static String veureNotaFinalFormatText ( double nota ){
            // Mostar la nota en el seu equivalent en text ; en el cas que la nota sigui
            //Insuficient mostrar la nota numerica .
            String laNota="";
            if (nota<5){
                
                laNota=Double.toString(nota);
            
            }else if (nota>=5 && nota<6){
                laNota="Suficient";
            }else if (nota>=6 && nota<7){
                laNota="Notable baix";
            }else if (nota>=7 && nota<9){
                laNota="Notable alt";
            }else if (nota>=9 && nota<=10){
                laNota="Excel·lent";
                
            }
            return laNota;
    }
    
}
