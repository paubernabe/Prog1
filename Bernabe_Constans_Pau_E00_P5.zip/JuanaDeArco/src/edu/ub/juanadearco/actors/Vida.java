/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.ub.juanadearco.actors;

import edu.ub.juanadearco.Actor;
import edu.ub.juanadearco.Colisio;
import edu.ub.juanadearco.Constants;
import edu.ub.juanadearco.Context;
import edu.ub.juanadearco.Util;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;

/**
 *
 * @author paubc
 */
public class Vida extends AbstractActor {
    
    private float energy=100.0f;
    private String nom;
    private int amplada;
    private int alcada;
    private Image image;

    
    
    public Vida(float energy, String nom,  int imgPosX, int imgPosY, int amplada, int alcada){
        this.energy=energy;
        this.nom=nom;
        this.amplada=amplada;
        this.alcada=alcada;
        //Utilitzar imatge de utils
        this.image = Util.carregarImatge("objectes.png", 
                imgPosX, imgPosY, amplada, alcada);
        
        setEstat(Constants.ESTAT_ACTIU);

    }
    public void setEnergy(float energy){
        this.energy=energy;
    }
    
    public float getEnergy(){
        return energy;
    }
    
    public void setNom(String nom){
        this.nom=nom;
        
    }
    public String getNom(){
        return nom;
    }

    @Override
    public void actualitzar(Context context) {
        //static
    }

    @Override
    public Rectangle getLimits() {
        return new Rectangle(getX(), getY(), amplada, alcada);
    }

    @Override
    public void tractarColisio(Colisio colisio) {
        Actor actor = colisio.getActor();
        if (actor instanceof Heroina) {
	        actor.setVida(energy);
	        setEstat(Constants.ESTAT_INACTIU);
        }
    }

    @Override
    public void render(Graphics2D g) {
        g.drawImage(image, getX(), getY(), observer);
        g.setColor(Color.GREEN);
        Font f = new Font("Dialog", Font.BOLD, 10);
        g.setFont(f);
        g.drawString(nom, getX(), getY() - 3);
    }
}
