/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.ub.juanadearco.actors;

import edu.ub.juanadearco.Actor;
import edu.ub.juanadearco.Colisio;
import edu.ub.juanadearco.Constants;
import edu.ub.juanadearco.Context;
import edu.ub.juanadearco.Util;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;

/**
 *
 * @author paubc
 */
public class Serpiente extends AbstractActor {
    
    private float dany= 50.0f;
    private int alcada, amplada;
    private Image image;
    private String nom;
    
    public Serpiente(float dany, String nom,  int imgPosX, int imgPosY, int amplada, int alcada){
        
        this.dany=dany;
        this.nom=nom;
        this.amplada=amplada;
        this.alcada=alcada;
        //Utilitzar imatge de utils
        this.image = Util.carregarImatge("objectes.png", 
                imgPosX, imgPosY, amplada, alcada);
        
        setEstat(Constants.ESTAT_ACTIU);
        
    }


    @Override
    public void actualitzar(Context context) {
        //
    }

    @Override
    public Rectangle getLimits() {
        return new Rectangle(getX(), getY(), amplada, alcada);

        
    }

    @Override
    public void tractarColisio(Colisio colisio) {
        Actor actor = colisio.getActor();
        if (actor instanceof Heroina) {
	        actor.setVida(Math.min(100.0f, actor.getVida() - dany));
	        setEstat(Constants.ESTAT_INACTIU);
        }
        
    }
    

    @Override
    public void render(Graphics2D g) {
        g.drawImage(image, getX(), getY(), observer);
        g.setColor(Color.GREEN);
        Font f = new Font("Dialog", Font.BOLD, 10);
        g.setFont(f);
        g.drawString(nom, getX(), getY() - 3);
    }
    
}
