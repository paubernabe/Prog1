/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.ub.juanadearco.actors;

import edu.ub.juanadearco.Actor;
import edu.ub.juanadearco.Colisio;
import edu.ub.juanadearco.Constants;
import edu.ub.juanadearco.Context;
import edu.ub.juanadearco.Util;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;

/**
 *
 * @author paubc
 */
public class Clau extends AbstractActor{
        private String nom;
        private int amplada, alcada;
        private Image image;
        
    public Clau(String nom, int imgPosX, int imgPosY, int imgAmplada, int imgAlcada){
        this.nom = nom;
        this.image = Util.carregarImatge("objectes.png", 
                imgPosX, imgPosY, imgAmplada, imgAlcada);
        this.amplada = imgAmplada;
        this.alcada = imgAlcada;
        setEstat(Constants.ESTAT_ACTIU);
            
    }
    
    public void setNom(String n){
        this.nom=n;
    }
    public String getNom(){
        return nom;
    }


    @Override
    public void actualitzar(Context context) {
        //
    }

   public Rectangle getLimits() {
        return new Rectangle(getX(), getY(), amplada, alcada);
    }

    @Override
    public void tractarColisio(Colisio colisio) {
        Actor actor = colisio.getActor();
        if (actor instanceof Heroina) {
        
        Heroina h= (Heroina) colisio.getActor();
        
        Colisio col= new Colisio(this);
        h.tractarColisio(col);
        
        
        setEstat(Constants.ESTAT_INACTIU);
        
        
        }
    }

    @Override
    public void render(Graphics2D g) {
        g.drawImage(image, getX(), getY(), observer);
        g.setColor(Color.GREEN);
        Font f = new Font("Dialog", Font.BOLD, 10);
        g.setFont(f);
        g.drawString(nom, getX(), getY() - 3);
    }
    
}
