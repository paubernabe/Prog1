/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinema;

/**
 *
 * @author paubc
 */
public class Cinema {
    
    int numFiles;
    int numButaquesF;
    boolean [][] butaques;

    Cinema(int numFiles, int numButaquesF){
        this.numFiles=numFiles;
        this.numButaquesF=numButaquesF;
        butaques= new boolean[numFiles][numButaquesF];
        //recorregut
        //inici i,j=0
        //condicio final i<numfiles, j<numbutaques
        for (int i=0; i<numFiles; i++){
            for (int j=0; j<numButaquesF; j++){
                
                butaques[i][j]=true;
            }
        }
    }
    
    int ocuparButaca(int fila, int columna){
        int retorn=0;
        
        if (fila<0 || columna<0 || fila>this.numFiles || columna>this.numButaquesF){
            
            retorn=-1;
        }else if(butaques[fila][columna]==false){
            
            retorn=-2;
        }else if (butaques[fila][columna]==true){
            butaques[fila][columna]=false;
            retorn=0;
        }
    return retorn;
    }
    
    int lliurarButaca(int fila, int columna){
        
    int retorn=0;
        
        if (fila<0 || columna<0 || fila>this.numFiles || columna>this.numButaquesF){
            retorn=-1;
        }
        else if(butaques[fila][columna]==true){
            
            retorn=-2;
        }else if (butaques[fila][columna]==false){
            butaques[fila][columna]=true;
            retorn=0;
        }
    return retorn;
    }
    
    /*
    Esquema: recorregut amb for
    i=0 comencem oel primer element
    j=0 comencem pel primer element 
    i,j=(0,0)
    Condicio sortida: i<butaquesa.length
    Condicio sortida for 2: i<butaques[i].lenght
    Cada iteració
    */
    void lliurarButaques(){
        for (int i=0; i<butaques.length; i++){
            for(int j=0; j<butaques[i].length; j++){
                butaques[i][j]=true;
            }
        }
    }
    
    void mostrarButaques(){
        int col=0;
        int fil=0;
        //Esquema: recorregut
        // inici i=0, j=0
        //condicio final bucle i: i>butaques
        //condicio final bucle j: j>butaques[i]
        for (int i=0; i<butaques.length; i++){
            for (int j=0; j<butaques[i].length; j++){
                
                if (i==0 || j==0){
                    if (i==0 && j==0){
                        System.out.print("Nº but" + " ");
                    }
                    if (i==0){
                        if (col!=butaques[i].length-1){
                            System.out.print(col++ + " ");
                        }
                    }
                    if (i==1+fil){
                        if (fil!=butaques.length){
                            System.out.print("Fila" + fil++ + ": ");
                            
                        }
                    }
                }else{
                
                
                    if (butaques[i][j]){
                        System.out.print("L" + " ");
                    }else{
                        System.out.print("O"+ " ");
                 
                    }
                }
                
                
                
            }
            System.out.println();
        
        
            
        }
    }
    
}
