/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinema;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author paubc
 */
public class CinemaTest {
    Cinema cine=new Cinema(5,5);
    public CinemaTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of ocuparButaca method, of class Cinema.
     */
    @Test
    public void testOcuparButaca() {
        System.out.println("ocuparButaca");
        int fila = 0;
        int columna = 0;
        int expResult = 0;
        int result = cine.ocuparButaca(fila+1, columna+1);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }

    /**
     * Test of lliurarButaca method, of class Cinema.
     */
    @Test
    public void testLliurarButaca() {
        System.out.println("lliurarButaca");
        int fila = 45;
        int columna = 21;
        int expResult = -1;
        int result = cine.lliurarButaca(fila+1, columna+1);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }
    
    @Test
    public void testLliurarButaca2() {
        System.out.println("lliurarButaca");
        int fila = 0;
        int columna = 0;
        int expResult = 0;
        cine.ocuparButaca(fila+1, columna+1);
        int result = cine.lliurarButaca(fila+1, columna+1);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }

    /**
     * Test of lliurarButaques method, of class Cinema.
     */
    @Test
    public void testLliurarButaques() {
        System.out.println("lliurarButaques");
        cine.lliurarButaques();
        // TODO review the generated test code and remove the default call to fail.
    }

    /**
     * Test of mostrarButaques method, of class Cinema.
     */
    @Test
    public void testMostrarButaques() {
        System.out.println("mostrarButaques");
        cine.mostrarButaques();
        // TODO review the generated test code and remove the default call to fail.
    }
    
}
