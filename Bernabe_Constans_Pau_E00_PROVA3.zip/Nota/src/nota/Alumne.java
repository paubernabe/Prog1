/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nota;

/**
 *
 * @author paubc
 */
public class Alumne {
    static double maxPuntsExtra=1.5;
    String nom;
    double progNotaTeoria1;
    double progNotaTeoria2;
    
    double algNotaTeoria1;
    double algNotaTeoria2;
    
    double progNotaFinal;
    double algoNotaFinal;
    
   
            
    
    
    Alumne ( String nom , double notaPT1, double notaPT2, double notaAT1, double notaAT2) {
        this . nom = nom ;
        this.progNotaTeoria1=notaPT1;
        this.progNotaTeoria2=notaPT2;
        this.algNotaTeoria1=notaAT1;
        this.algNotaTeoria2=notaAT2;
        
                
        

    }
    
    static void modificarMaxPuntsExtra ( double max ){
        maxPuntsExtra = max ;
    }
    void calculaNotaFinal () {


          this.progNotaFinal=(progNotaTeoria1+progNotaTeoria2)/2;
          if (this.progNotaFinal>=6 && this.progNotaFinal<=7){
              this.progNotaFinal=this.progNotaFinal+maxPuntsExtra;
          }
          
          this.algoNotaFinal=(this.algNotaTeoria1*0.6+this.algNotaTeoria2*0.4);
          if (this.algoNotaFinal>=4 && this.algoNotaFinal<=6){
              this.algoNotaFinal=this.algoNotaFinal+(maxPuntsExtra*0.5);
              
          }else if (this.algoNotaFinal>6){
              this.algoNotaFinal=this.algoNotaFinal+maxPuntsExtra;
          }else if(this.algoNotaFinal<4){
              this.algoNotaFinal=this.algoNotaFinal+0;
          }
          
         //he eliminat els punts extra, ja que no es demanen, nomes masPuntsExtra
          
    }
    
    int obtenirNotaMajor(){
        int major;
        if (this.algNotaTeoria1>this.algNotaTeoria2 && this.algNotaTeoria1>this.progNotaTeoria1 && this.algNotaTeoria1>this.progNotaTeoria2){
            major=(int)(this.algNotaTeoria1);
        }
        else if (this.algNotaTeoria2>this.algNotaTeoria1 && this.algNotaTeoria2>this.progNotaTeoria1 && this.algNotaTeoria2>this.progNotaTeoria2){
            major=(int)this.algNotaTeoria2;
        }
        else if(this.progNotaTeoria1>this.algNotaTeoria1 && this.progNotaTeoria1>this.algNotaTeoria2 && this.progNotaTeoria1>this.progNotaTeoria2){
            major=(int)this.progNotaTeoria1;
        }else{
            major=(int)this.progNotaTeoria2;
        }
        return major;
        //he fet el cast explicit de double a int per a fer el retorn.
    }
    
    
    void mostrarAlumne(){
        
        System.out.println("Nom: "+this.nom);
        System.out.println("Nota de Programació: "+Nota.veureNotaFinalFormatText(this.progNotaFinal)+" : " + this.progNotaFinal);
        System.out.println("Nota d'Algorismica: "+Nota.veureNotaFinalFormatText(this.algoNotaFinal));
        
    }
}

//PREGUNTES
/*
(b) En la classe Alumne, quins s´on atributs de classe i quins s´on atributs d’objecte? Raoneu
la vostra resposta.

R//
Els atributs d'objecte són tots, excepte el static double maxpuntsExtra. Això es deu a que
nosaltres al crear un objecte d'aquesta classe, podrem canviar els valors als atributs i a cada objecte tenir
valors diferents als nostres atributs.

En canvi el static maxpuntsextra, al ser un atribut de classe, serà el mateix valor per a tots els objectes.

*/
//-----------------------------------------------------------------------------------------
/*
Els m`etodes veureNotaFinalFormatText() i modificarMaxPuntsExtra() s´on m`etodes
de classe o m`etodes d’objecte? Per qu`e?

R// 
El metode veureNotaFinalFormatText() és un mètode d'objecte ja que només podem cridar-lo amb l'objecte 
d'aquella classe en particular. El podem cridar: objecteAlumne.metode()

En canvi modificarMaxPuntsExtra() és un mètode de classe ja que és static i a més no es pot cridar amb una
instancia de la classe.
El podem cridar: Alumne.metode()

*/