/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nota;

/**
 *
 * @author pau bernabe
 */
import java.util.*;
public class Nota {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Quin es el nom de l'alumne?");
        String nom=sc.next();
        System.out.println("Quina es la nota del primer parcial de programació?");
        double nota1=sc.nextDouble();
        if (nota1<0 || nota1>10){
            System.out.println("Introdueix be la nota del primer parcial de programacio");
            nota1=sc.nextDouble();
        }
        System.out.println("Quina es la nota del segon parcial de programació?");
        double nota2=sc.nextDouble();
        if (nota2<0 || nota2>10){
            System.out.println("Introdueix be la nota del segon parcial de programació");
            nota2=sc.nextDouble();
        }
        
        System.out.println("Quina es la nota del primer parcial d'algorismica?");
        double nota3=sc.nextDouble();
        if (nota3<0 || nota3>10){
            System.out.println("Introdueix be la nota del primer parcial d'algorismica");
            nota3=sc.nextDouble();
        }
        
        System.out.println("Quina es la nota del segon parcial d'algorismica?");
        double nota4=sc.nextDouble();
        if (nota4<0 || nota4>10){
            System.out.println("Introdueix be la nota del segon parcial d'algorismica");
            nota4=sc.nextDouble();
        }
        
        
                
        

        Alumne meualumne = new Alumne(nom,nota1,nota2,nota3,nota4);
        meualumne.calculaNotaFinal();
        meualumne.mostrarAlumne();
        System.out.println("La major nota de les quatre és: " +meualumne.obtenirNotaMajor());
        
        
        
        
    }
    static String veureNotaFinalFormatText ( double nota ){
            // Mostar la nota en el seu equivalent en text ; en el cas que la nota sigui
            //Insuficient mostrar la nota numerica .
            String laNota="";
            if (nota<5){
                
                laNota="Insuficient";
            
            }else if (nota>=5 && nota<6){
                laNota="Suficient";
            }else if (nota>=6 && nota<7){
                laNota="Notable baix";
            }else if (nota>=7 && nota<9){
                laNota="Notable alt";
            }else if (nota>=9 && nota<=10){
                laNota="Excel·lent";
                
            }
            return laNota;
    }
    
}
